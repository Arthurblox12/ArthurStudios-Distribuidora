from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title='Arthur Studios API')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*'],
)

@app.get('/')
def home():
    return {'status': 'Arthur Studios API Online'}

@app.post('/upload')
async def upload(file: UploadFile = File(...)):
    return {
        'file': file.filename,
        'royalties': '100% artista',
        'exclusive': 'Arthur Studios'
    }
