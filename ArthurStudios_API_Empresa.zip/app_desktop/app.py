import tkinter as tk

root = tk.Tk()
root.title('Arthur Studios')

tk.Label(root, text='Arthur Studios Distribuidora').pack(pady=20)
root.mainloop()
